import React, { useState } from 'react';
    import './App.css';

    function App() {
      const [tasks, setTasks] = useState([]);

      const addTask = (task) => {
        setTasks([...tasks, { text: task, done: false }]);
      };

      const deleteTask = (index) => {
        const newTasks = [...tasks];
        newTasks.splice(index, 1);
        setTasks(newTasks);
      };

      const markTaskAsDone = (index) => {
        const newTasks = [...tasks];
        newTasks[index].done = true;
        setTasks(newTasks);
      };

      return (
        <div className="app-container">
          <h1>Simple To-Do App</h1>
          <AddTaskForm addTask={addTask} />
          <TaskList tasks={tasks} deleteTask={deleteTask} markTaskAsDone={markTaskAsDone} />
        </div>
      );
    }

    function AddTaskForm({ addTask }) {
      const [task, setTask] = useState('');

      const handleSubmit = (e) => {
        e.preventDefault();
        addTask(task);
        setTask('');
      };

      return (
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={task}
            onChange={(e) => setTask(e.target.value)}
            placeholder="Add a new task"
          />
          <button type="submit">Add</button>
        </form>
      );
    }

    function TaskList({ tasks, deleteTask, markTaskAsDone }) {
      return (
        <ul>
          {tasks.map((task, index) => (
            <li key={index}>
              <span style={{ textDecoration: task.done ? 'line-through' : 'none' }}>{task.text}</span>
              <button onClick={() => markTaskAsDone(index)}>Done</button>
              <button onClick={() => deleteTask(index)}>Delete</button>
            </li>
          ))}
        </ul>
      );
    }

    export default App;
